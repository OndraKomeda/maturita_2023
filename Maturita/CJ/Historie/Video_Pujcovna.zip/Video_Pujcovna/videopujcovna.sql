CREATE DATABASE  IF NOT EXISTS `videopujcovna` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `videopujcovna`;
-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: videopujcovna
-- ------------------------------------------------------
-- AUTOR:
-- ONDRA KOMEDA C4B
-- VYTVOŘENO 25.1.2023

-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dvd`
--

DROP TABLE IF EXISTS `dvd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dvd` (
  `cena` float DEFAULT NULL,
  `stav` enum('nove','rozbalene','poskrabane','znicene') DEFAULT NULL,
  `vypujceno` tinyint(1) DEFAULT '0',
  `id` int NOT NULL AUTO_INCREMENT,
  `film_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `film_id` (`film_id`),
  CONSTRAINT `dvd_ibfk_1` FOREIGN KEY (`film_id`) REFERENCES `filmy` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dvd`
--

LOCK TABLES `dvd` WRITE;
/*!40000 ALTER TABLE `dvd` DISABLE KEYS */;
INSERT INTO `dvd` VALUES (500,'nove',0,1,1),(200,'poskrabane',0,2,2),(400,'rozbalene',0,3,3),(1100,'nove',0,4,4);
/*!40000 ALTER TABLE `dvd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filmy`
--

DROP TABLE IF EXISTS `filmy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filmy` (
  `nazev_filmu` varchar(255) DEFAULT NULL,
  `rok_vydani` int DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filmy`
--

LOCK TABLES `filmy` WRITE;
/*!40000 ALTER TABLE `filmy` DISABLE KEYS */;
INSERT INTO `filmy` VALUES ('The Great Gatsby',2013,1),('Avatar 2',2022,2),('Toy Story 4',2019,3),('The Raven',2012,4);
/*!40000 ALTER TABLE `filmy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recenze`
--

DROP TABLE IF EXISTS `recenze`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recenze` (
  `text` varchar(255) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `zakaznik_id` int NOT NULL,
  `dvd_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `zakaznik_id` (`zakaznik_id`),
  KEY `dvd_id` (`dvd_id`),
  CONSTRAINT `recenze_ibfk_1` FOREIGN KEY (`zakaznik_id`) REFERENCES `zakaznik` (`id`),
  CONSTRAINT `recenze_ibfk_2` FOREIGN KEY (`dvd_id`) REFERENCES `dvd` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recenze`
--

LOCK TABLES `recenze` WRITE;
/*!40000 ALTER TABLE `recenze` DISABLE KEYS */;
INSERT INTO `recenze` VALUES ('DVD hralo jak ma',1,1,1),('DVD je bozi',2,2,2),('DVD bylo trosku poskrabane',3,3,3),('DVD se obcas zaseklo',4,4,4);
/*!40000 ALTER TABLE `recenze` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `view_recenze`
--

DROP TABLE IF EXISTS `view_recenze`;
/*!50001 DROP VIEW IF EXISTS `view_recenze`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_recenze` AS SELECT 
 1 AS `id`,
 1 AS `text`,
 1 AS `jmeno`,
 1 AS `prijmeni`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_volne_dvd`
--

DROP TABLE IF EXISTS `view_volne_dvd`;
/*!50001 DROP VIEW IF EXISTS `view_volne_dvd`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_volne_dvd` AS SELECT 
 1 AS `id`,
 1 AS `stav`,
 1 AS `nazev_filmu`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_vypujcene_dvd`
--

DROP TABLE IF EXISTS `view_vypujcene_dvd`;
/*!50001 DROP VIEW IF EXISTS `view_vypujcene_dvd`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_vypujcene_dvd` AS SELECT 
 1 AS `id`,
 1 AS `stav`,
 1 AS `nazev_filmu`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `vypujcka`
--

DROP TABLE IF EXISTS `vypujcka`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vypujcka` (
  `datum_vypujceni` date DEFAULT (curdate()),
  `datum_vraceni` date DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `zakaznik_id` int NOT NULL,
  `dvd_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `zakaznik_id` (`zakaznik_id`),
  KEY `dvd_id` (`dvd_id`),
  CONSTRAINT `vypujcka_ibfk_1` FOREIGN KEY (`zakaznik_id`) REFERENCES `zakaznik` (`id`),
  CONSTRAINT `vypujcka_ibfk_2` FOREIGN KEY (`dvd_id`) REFERENCES `dvd` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vypujcka`
--

LOCK TABLES `vypujcka` WRITE;
/*!40000 ALTER TABLE `vypujcka` DISABLE KEYS */;
/*!40000 ALTER TABLE `vypujcka` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zakaznik`
--

DROP TABLE IF EXISTS `zakaznik`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `zakaznik` (
  `jmeno` varchar(255) DEFAULT NULL,
  `prijmeni` varchar(255) DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zakaznik`
--

LOCK TABLES `zakaznik` WRITE;
/*!40000 ALTER TABLE `zakaznik` DISABLE KEYS */;
INSERT INTO `zakaznik` VALUES ('Petr','Pavel',1),('Andrej','Babis',2),('Milos','Zeman',3),('Barack','Obama',4);
/*!40000 ALTER TABLE `zakaznik` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `view_recenze`
--

/*!50001 DROP VIEW IF EXISTS `view_recenze`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_recenze` AS select `dvd`.`id` AS `id`,`recenze`.`text` AS `text`,`zakaznik`.`jmeno` AS `jmeno`,`zakaznik`.`prijmeni` AS `prijmeni` from (((`recenze` join `zakaznik` on((`recenze`.`zakaznik_id` = `zakaznik`.`id`))) join `dvd` on((`recenze`.`dvd_id` = `dvd`.`id`))) join `filmy` on((`dvd`.`film_id` = `filmy`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_volne_dvd`
--

/*!50001 DROP VIEW IF EXISTS `view_volne_dvd`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_volne_dvd` AS select `dvd`.`id` AS `id`,`dvd`.`stav` AS `stav`,`filmy`.`nazev_filmu` AS `nazev_filmu` from (`dvd` join `filmy` on((`dvd`.`film_id` = `filmy`.`id`))) where (`dvd`.`vypujceno` = false) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_vypujcene_dvd`
--

/*!50001 DROP VIEW IF EXISTS `view_vypujcene_dvd`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_vypujcene_dvd` AS select `dvd`.`id` AS `id`,`dvd`.`stav` AS `stav`,`filmy`.`nazev_filmu` AS `nazev_filmu` from (`dvd` join `filmy` on((`dvd`.`film_id` = `filmy`.`id`))) where (`dvd`.`vypujceno` = true) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-25 12:28:49
