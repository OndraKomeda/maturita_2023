class DVD_table:
    def __init__(self, price, state, lent, movie_id, id = None):
        self.price = price
        self.state = state
        self.lent = lent
        self.movie_id = movie_id
        self.id = id

class Movie_table:
    def __init__(self, name, release_year, id = None):
        self.name = name
        self.release_year = release_year
        self.id = id

class Vypujcka_table:
    def __init__(self, return_date, customer_id, dvd_id, id = None):
        self.return_date = return_date
        self.customer_id = customer_id
        self.dvd_id = dvd_id
        self.id = id

class Customer_table:
    def __init__(self, name, last_name, id = None):
        self.id = id
        self.name = name
        self.last_name = last_name