
class db_config:

    def __init__(self):
        self.set_config_from_file()

    def set_config_from_file(self):
        try:
            sf = __file__
            config_file = open(__file__+"/../../../data/db.conf",'r')
            config = config_file.read().splitlines()
            self.host = config[0]
            self.user = config[1]
            self.password = config[2]
            self.port = config[3]
        except:
            raise "Error: 1"