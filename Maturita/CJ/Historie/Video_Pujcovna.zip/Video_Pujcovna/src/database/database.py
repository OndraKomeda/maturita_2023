import mysql.connector
from database.db_config import db_config
from database.Views import *
from database.Tables import *

class Database:
    def __new__(cls):
        if not hasattr(cls, 'instance'):
            cls.instance = super(Database, cls).__new__(cls)
        return cls.instance

    def __init__(self):
        self.connect_db()

    def connect_db(self) -> bool:
        file_config = db_config()
        try:
            self.connection = mysql.connector.connect(host=file_config.host,
                                                      user=file_config.user,
                                                      password=file_config.password,
                                                      port=3000)
            return 1
        except:
            raise "Error 1: Can't connect."

    def get_all_reviews(self):
        cursor = self.connection.cursor()
        query = ("select * from videopujcovna.view_recenze")
        cursor.execute(query)

        reviews = []
        for(id,text,jmeno,prijmeni) in cursor:
            reviews.append(Review_view(id,text,jmeno,prijmeni))
        return reviews

    def get_all_available_DVD(self):
        cursor = self.connection.cursor()
        query = ("select * from videopujcovna.view_volne_dvd")
        cursor.execute(query)

        all_available_DVD = []
        for (id, stav, nazev_filmu) in cursor:
            all_available_DVD.append(DVD_view(id,stav,nazev_filmu))
        return all_available_DVD

    def get_all_lent_DVD(self):
        cursor = self.connection.cursor()
        query = ("select * from videopujcovna.view_vypujcene_dvd")
        cursor.execute(query)

        all_available_DVD = []
        for (id, stav, nazev_filmu) in cursor:
            all_available_DVD.append(DVD_view(id,stav,nazev_filmu))
        return all_available_DVD

    def get_all_customers(self):
        cursor = self.connection.cursor()
        query = ("select * from videopujcovna.zakaznik")
        cursor.execute(query)

        all_customers = []
        for (jmeno, prijmeni, id) in cursor:
            all_customers.append(Customer_table(jmeno, prijmeni, id))
        return all_customers

    def insert_vypujcka(self, return_date, dvd_id,customer_id):
        available_dvds = self.get_all_available_DVD()

        is_dvd_available = False
        for dvd in available_dvds:
            if dvd.id == dvd_id:
                is_dvd_available = True

        customers = self.get_all_customers()

        does_customer_exist = False
        for customer in customers:
            if customer.id == customer_id:
                does_customer_exist = True

        if does_customer_exist and is_dvd_available:
            cursor = self.connection.cursor()
            query = ("insert into videopujcovna.vypujcka(datum_vraceni,zakaznik_id,dvd_id) values('{}',{},{})").format(return_date,customer_id,dvd_id)
            cursor.execute(query)
            query = ("update videopujcovna.dvd set vypujceno=True where id="+str(dvd_id))
            cursor.execute(query)
            self.connection.commit()

    def return_DVD(self,state,dvd_id):
        lent_dvds = self.get_all_lent_DVD()

        is_dvd_lent = False
        for dvd in lent_dvds:
            if dvd.id == dvd_id:
                is_dvd_lent = True

        if is_dvd_lent and not state == 'znicene':
            cursor = self.connection.cursor()
            query = ("update videopujcovna.dvd set vypujceno=False,stav=\'"+state+"\' where id="+str(dvd_id))
            cursor.execute(query)
            self.connection.commit()
        elif is_dvd_lent:
            cursor = self.connection.cursor()
            query = ("delete from videopujcovna.dvd where id=" + str(dvd_id))
            cursor.execute(query)
            self.connection.commit()

    def get_all_movies(self):
        cursor = self.connection.cursor()
        query = ("select * from videopujcovna.filmy")
        cursor.execute(query)

        all_movies = []
        for (nazev_filmu, rok_vydani, id) in cursor:
            all_movies.append(Movie_table(nazev_filmu, rok_vydani, id))
        return all_movies

    def insert_DVDs(self,DVDs):
        for DVD in DVDs:
            cursor = self.connection.cursor()
            query = ("insert into videopujcovna.DVD(cena,stav,film_id) values({},'{}',{})").format(DVD.price,DVD.state,DVD.movie_id)
            cursor.execute(query)
            self.connection.commit()

    def insert_Movies(self,Movies):
        for Movie in Movies:
            cursor = self.connection.cursor()
            query = ("insert into videopujcovna.filmy(nazev_filmu,rok_vydani) values('{}','{}')").format(Movie.name,Movie.release_year)
            cursor.execute(query)
            self.connection.commit()