class DVD_view:
    def __init__(self,id, state, movie_name):
        self.id = id
        self.state = state
        self.movie_name = movie_name

class Review_view:
    def __init__(self,id_dvd, review_text, author_name, author_last_name):
        self.id_dvd = id_dvd
        self.review_text = review_text
        self.author_name = author_name
        self.author_last_name = author_last_name