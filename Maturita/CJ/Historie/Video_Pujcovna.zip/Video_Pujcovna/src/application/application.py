from database.database import Database
from presentation.presentation import Presentation
from database.Tables import *

class Application:
    def __init__(self):
        self.db = Database()
        self.presentation = Presentation()

    def run(self):
        while True:
            self.presentation.print_menu()
            user_input = input()
            if not self.is_valid_input(user_input):
                continue
            self.choose_action(int(user_input))

    def is_valid_input(self, input):
        try:
            int(input)
            return True
        except:
            return False

    def choose_action(self, action_number):
        match action_number:
            case 1:
                self.presentation.print_text("Postupne zadej datum vraceni, id dvd a id zakaznika.")
                return_date = input()
                dvd_id = input()
                customer_id = input()
                self.db.insert_vypujcka(return_date, int(dvd_id), int(customer_id))
            case 2:
                self.presentation.print_text("Postupne zadej stav(nove,rozbalene,poskrabane,znicene) a pak id DVD.")
                state = input()
                dvd_id = input()
                self.db.return_DVD(state,int(dvd_id))
            case 3:
                self.presentation.print_text("Zadej cestu k souboru CSV s formatem CENA,STAV a FILM_ID")
                file_path = input()
                self.db.insert_DVDs(self.get_DVDs_from_csv(file_path))
            case 4:
                self.presentation.print_Reviews(self.db.get_all_reviews())
            case 5:
                self.presentation.print_DVDs(self.db.get_all_available_DVD())
            case 6:
                self.presentation.print_DVDs(self.db.get_all_lent_DVD())
            case 7:
                self.presentation.print_text("Zadej cestu k souboru CSV s formatem NAZEV a ROK_VYDANI")
                file_path = input()
                self.db.insert_Movies(self.get_Movies_from_csv(file_path))
            case 8:
                exit(1)
            case _:
                pass

    def get_DVDs_from_csv(self,file_path):
        try:
            file = open(file_path)

            DVDs = []
            lines = file.readlines()
            for line in lines:
                line = line.replace("\n","")
                columns = line.split(',')
                DVDs.append(DVD_table(columns[0],columns[1],0,columns[2]))
            return DVDs
        except:
            raise "Error: Can't open CSV file."

    def get_Movies_from_csv(self,file_path):
        try:
            file = open(file_path)

            Movies = []
            lines = file.readlines()
            for line in lines:
                line = line.replace("\n","")
                columns = line.split(',')
                Movies.append(Movie_table(columns[0],columns[1]))
            return Movies
        except:
            raise "Error: Can't open CSV file."