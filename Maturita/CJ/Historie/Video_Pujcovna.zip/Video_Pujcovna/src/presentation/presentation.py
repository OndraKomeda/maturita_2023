class Presentation:

    def print_menu(self):
        menu_text = "Vyberte moznost cislem.\n" \
                    "1. Vypujceni DVD\n" \
                    "2. Vraceni DVD\n" \
                    "3. Import DVD z CSV\n" \
                    "4. Vypsani list recenzi DVD a jejich autoru\n" \
                    "5. Vypsani volnych DVD\n" \
                    "6. Vypsani vypujcenych DVD\n" \
                    "7. Import filmu z CSV\n" \
                    "8. Konec"
        print(menu_text)

    def print_text(self, text_str):
        print(text_str)

    def print_error(self,error_code):
        print("An error has occured. Please check the error code: "+str(error_code)+" in the documentation.")

    def print_Reviews(self,Reviews):
        text = "---------------------------\n" \
               "id_dvd     author_name     author_last_name     review_text\n"
        for Review in Reviews:
            text+=str(Review.id_dvd)+"     "+Review.author_name+"     "+Review.author_last_name+"     \""+Review.review_text+"\"\n"

        print(text)

    def print_DVDs(self,DVDs):
        text = "---------------------------\n" \
               "id_dvd     dvd_state     movie_name\n"
        for DVD in DVDs:
            text += str(DVD.id) + "     " + DVD.state + "     " + DVD.movie_name + "\n"

        print(text)
