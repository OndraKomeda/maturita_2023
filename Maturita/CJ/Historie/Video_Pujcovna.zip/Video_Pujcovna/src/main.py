from application.application import Application

app = Application()
app.run()