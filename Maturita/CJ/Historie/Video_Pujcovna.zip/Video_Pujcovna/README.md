Ondra Komeda
ondra.komeda@gmail.com

## Veškerá podrobnější dokumentace je umístěna ve "Video_Pujcovna/doc/".

Je potřeba importovat databázi z Video_Pujcovna/videopujcovna.sql
K vývoji db byl použit MySQL workbench. 

Dále pokud není nainstalovaný package MySQL connector tak je potřebný nainstalovat do venv pomocí příkazu
pip install mysql-connector-python 

Program je potom potřeba spustit z main.py 